int main()
{
    int a,b,c;
    a = b + c;
    if (a>b){ a = b+c; }else{ a = b-c; }
    while(a < b){ a = a+c; }
}