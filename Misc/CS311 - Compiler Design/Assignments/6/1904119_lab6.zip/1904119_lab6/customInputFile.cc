int main(){
    int a;
    float b, c;
    a = 4.5;        
    c = b + c;      
    a = b + 6.5;    
    if(a>b){ a = b + c;}else{ a = b - c; }   
    while(a<b){ a = a+c+d;}                  
}