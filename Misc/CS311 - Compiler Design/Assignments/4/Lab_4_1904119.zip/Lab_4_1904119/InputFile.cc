int main(){

	int a, b;
	float d;
	char c;
}
