/* The function is used to calculate the sum of two numbers */
int         add(int a, int b)
{
return a+b;
}
int main()
{
int x = add(5, 7);
}