- The code for the Lexical Analyser is written in python and named as `LexicalAnalyser_1904119.py`

- The input code files for the Lexical Analyser are in C++. It is assumed that the input code files are syntactically correct
and has only the following keywords in their code : "if", "then", "else", "int", "return"

- There are 2 Input code files on which the Lexical Analyser is tested. 
    - One is the source code given as part of assignment.   ( inputFile1.cc )
    - Second one is the custom code written by me to check. ( inputFile2.cc )

- The code to execute the Lexical Analyser is as follows: `LexicalAnalyser_1904119.py`